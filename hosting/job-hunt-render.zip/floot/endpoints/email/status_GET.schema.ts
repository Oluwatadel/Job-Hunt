export type OutputType = Record<string, unknown>;
